import deckofcards as doc
import suits
from turtle import *
from time import sleep
from random import randint

class Dealer(doc.Player):
    
    def __init__(self,name):
        self.name=name
        self.hand=[]
        self.position=[-395,-235,-75,85,245,405,565,725]
        self.offset=350
        self.faceup =[False,True,True,True,True,True,True,True]
        return
    
    def play(self):
        self.hand[0].drawing.face=True
        suits.move(self.position[0],self.offset)
        self.hand[0].show()
        score(mrhouse,-260,100)
        sleep(1)
        while count(bob)>count(mrhouse) and count(bob)<22 and not (count(bob)==21 and len(bob.hand)==2):
            mrhouse.draw(deck,1)
            score(mrhouse,-260,100)
            sleep(1)
        if (count(bob)-count(mrhouse)>0 and count(bob)<22) or (count(bob)==21 and len(bob.hand)==2) or (count(bob)<22 and count(mrhouse)>21):
            suits.move(-120,25)
            color('blue')
            write('You Won!',False,align='left',font=('courier',45,'bold'))
            ######################################################################
            chips.chips_val=chips.chips_val+len(chips.pot1)+10*len(chips.pot10)+50*len(chips.pot50)+100*len(chips.poth)
        else:
            suits.move(-120,25)
            color('red')
            write('You Lost!',False,align='left',font=('courier',45,'bold'))
            ######################################################################
            chips.chips_val=chips.chips_val-len(chips.pot1)-10*len(chips.pot10)-50*len(chips.pot50)-100*len(chips.poth)
        sleep(1)
        return
    
class Chips:
    
    def __init__(self,amt):
        self.chips_val=amt
        self.chips1=[]
        self.chips10=[]
        self.chips50=[]
        self.chipsh=[]
        self.pot1=[]
        self.pot10=[]
        self.pot50=[]
        self.poth=[]
        self.all_chips=[self.chips1,self.chips10,self.chips50,self.chipsh]
        self.all_pots=[self.pot1,self.pot10,self.pot50,self.poth]
        return
    
    def clicky1(self,x,y):
        if y<80:
            q=self.chips1.pop()
            q.goto(randint(500,740),randint(150,270))
            self.pot1.append(q)
        else:
            q=self.pot1.pop()
            q.goto(740,0)
            self.chips1.append(q)
        money(self)
        update()
        return
        
    def clicky10(self,x,y):
        if y<80:
           q=self.chips10.pop()
           q.goto(randint(500,740),randint(150,270))
           self.pot10.append(q)
        else:
            q=self.pot10.pop()
            q.goto(660,0)
            self.chips10.append(q)
        money(self)
        update()
        return

    def clicky50(self,x,y):
        if y<80:
            q=self.chips50.pop()
            q.goto(randint(500,740),randint(150,270))
            self.pot50.append(q)
        else:
            q=self.pot50.pop()
            q.goto(580,0)
            self.chips50.append(q)
        money(self)
        update()
        return

    def clickyh(self,x,y):
        if y<80:
            q=self.chipsh.pop()
            q.goto(randint(500,740),randint(150,270))
            self.poth.append(q)
        else:
            q=self.poth.pop()
            q.goto(500,0)
            self.chipsh.append(q)
        money(self)
        update()
        return  
            
    
    def give_chips(self):
        v=self.chips_val
        while v>300:####makes $100 chips
            chiph=Turtle()
            chiph.shape('circle')
            chiph.color('gold')
            chiph.shapesize(4,4,4)
            chiph.penup()
            chiph.goto(500,0)
            chiph.onclick(self.clickyh)
            self.chipsh.append(chiph)
            v-=100
        while v>=100:####makes $50 chips
            chip50=Turtle()
            chip50.seth(90)
            chip50.shape('circle')
            chip50.color('blue')
            chip50.shapesize(4,4,4)
            chip50.penup()
            chip50.goto(580,0)
            chip50.onclick(self.clicky50)
            self.chips50.append(chip50)
            v-=50
        while v>=20:####makes $10 chips
            chip10=Turtle()
            chip10.shape('circle')
            chip10.color('green')
            chip10.shapesize(4,4,4)
            chip10.penup()
            chip10.goto(660,0)
            chip10.onclick(self.clicky10)
            self.chips10.append(chip10)
            v-=10
        while v>0:####makes $1 chips
            chip1=Turtle()
            chip1.shape('circle')
            chip1.shapesize(4,4,4)
            chip1.penup()
            chip1.goto(740,0)
            chip1.onclick(self.clicky1)
            self.chips1.append(chip1)
            v-=1
        update()
        return
    
    def clean_chips(self):
        for i in self.all_chips:
            for j in i:
                j.hideturtle()
            i[:]=[]    
        for i in self.all_pots:
            for j in i:
                j.hideturtle()
            i[:]=[]
        return

mrhouse=Dealer('Mr. House')
bob=doc.Player('bob')
deck=doc.Deck()
chips=Chips(500)

def start():
    suits.move(-680,380)
    suits.move(xcor()+6,ycor())
    color('black','white')
    begin_fill()
    for i in range(2):
        fd(138)
        for i in range(90):
            fd(0.105)
            rt(1)
        fd(208)
        for i in range(90):
            fd(0.105)
            rt(1)
    end_fill()
    suits.move(xcor()-6,ycor())
    suits.move(-645,120)
    color('white')
    write('Hit',False,align='left',font=('courier',23,'bold'))
    suits.move(0,0)
    color('cyan')
    begin_fill()
    for i in range(4):
        fd(100)
        for i in range(90):
            rt(1)
            fd(0.1)
    end_fill()
    suits.move(-5,-70)
    color('black')
    write('stand',False,align='left',font=('courier',22,'bold'))
    for i in range(len(bob.hand)):
        deck.cards.append(bob.hand.pop())
    for i in range(len(mrhouse.hand)):
        deck.cards.append(mrhouse.hand.pop())
    deck.shuffle()
    chips.clean_chips()
    #######
    chips.give_chips()
    money(chips)
    #######
    #betting
    t=10
    while t>0:
        suits.move(350,-100)
        write('Time left to bet:{}'.format(t),False,align='left',font=('courier',23,'bold'))
        sleep(1)
        t-=1
        color('dark green')
        suits.move(340,-50)
        begin_fill()
        for i in range(2):
            fd(450)
            rt(90)
            fd(50)
            rt(90)
        end_fill()
        color('white')
    for i in chips.all_chips:
        for j in i:
            j.onclick(None)
    for i in chips.all_pots:
        for j in i:
            j.onclick(None)
    #######
    bob.draw(deck,2)
    mrhouse.draw(deck,2)
    score(bob,-740,-100)
    win_lose()
    print(count(bob))
    return

def win_lose():
    sleep(.5)
    if count(bob)==21:
        print("21!")
        mrhouse.play()
        clear()
        start()
    elif count(bob)>21:
        print("YOU LOST!!!!!")
        mrhouse.play()
        clear()
        start()
    else:
        pass
    return

def clicky(x,y):
    Screen().onclick(None)
    if x>-680 and x<-530 and y<380 and y>160 and len(bob.hand)<11:
        bob.draw(deck,1)
        print(count(bob))
        score(bob,-740,-100)
        win_lose()
    if x>0 and x<100 and y<0 and y>-100:
        print('stand')
        mrhouse.play()
        clear()
        start()
    Screen().onclick(clicky)
    return

Screen().onclick(clicky)

def score(Player,x,y):
    color('dark green')
    suits.move(x,y)
    begin_fill()
    for i in range(4):
        fd(50)
        rt(90)
    end_fill()
    color('white')
    suits.move(x,y-35)
    write(count(Player),False,align='left',font=('courier',23,'bold'))
    return

def money(Chips):
    suits.move(350,350)
    color('dark green')
    begin_fill()
    for i in range(4):
        fd(100)
        rt(90)
    end_fill()
    color('white')
    suits.move(350,300)
    ##### Discrepancy between here and Dealer.play
    pot_chips=len(Chips.pot1)+10*len(Chips.pot10)+50*len(Chips.pot50)+100*len(Chips.poth) #######################################
    write('${}'.format(pot_chips),False,align='left',font=('courier',23,'bold'))   
    suits.move(350,50)
    color('dark green')
    begin_fill()
    for i in range(4):
        fd(100)
        rt(90)
    end_fill()
    color('white')
    suits.move(350,0)
    player_chips=len(Chips.chips1)+10*len(Chips.chips10)+50*len(Chips.chips50)+100*len(Chips.chipsh)
    write('${}'.format(player_chips),False,align='left',font=('courier',23,'bold'))
    return

def count(Player):
    num=0
    aces=0
    for c in Player.hand:
        if c.value>1 and c.value<11:
            num+=c.value
        elif c.value>10:
            num+=10
        else:
            num+=11
            aces+=1
    while aces>0:
        if num>21:
            num-=10
        aces-=1
    return num

start()